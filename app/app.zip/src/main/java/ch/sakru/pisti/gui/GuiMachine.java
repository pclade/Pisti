package ch.sakru.pisti.gui;

public class GuiMachine {
}
