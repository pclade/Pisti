package ch.sakru.pisti.game;

public enum MaxPoints {
    MAX_51, MAX_101, MAX_151
}
